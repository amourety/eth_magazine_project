create view v_students as
  SELECT student.id, student.name, student.surname, university.name AS university_name
  FROM (student
      JOIN university ON (((student.id_university = university.id) AND ('teacher' :: name = CURRENT_USER))));

alter table v_students
  owner to postgres;

