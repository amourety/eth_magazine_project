create materialized view mv_students as
  SELECT student.id, student.name, student.surname, university.name AS university_name
  FROM (student
      JOIN university ON ((student.id_university = university.id)));

alter materialized view mv_students
  owner to postgres;

